<footer class="footer">
      <div class="wrapper footer__separator">
        <div class="footer__left">
          <img src="<?php echo get_template_directory_uri(); ?>./assets/copyright2.png">
          <p class="footer__text">Win-Pol Copyright 2023</p>
        </div>
        <a href="#" class="footer__text">Privacy Policy</a>
      </div>
    </footer>
    <script src="<?php echo get_template_directory_uri(); ?>./scripts/main.js"></script>
    <script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>./assets/slick/slick.min.js"></script>
    <script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>./scripts/myslider.js"></script>
    <?php wp_footer(); ?>
  </body>
</html>